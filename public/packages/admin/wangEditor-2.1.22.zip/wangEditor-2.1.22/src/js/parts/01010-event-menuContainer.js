// 菜单container事件
_e(function (E, $) {

    E.fn.eventMenuContainer = function () {

    };

});